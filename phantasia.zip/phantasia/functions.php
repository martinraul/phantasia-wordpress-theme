<?php 

function learningWordpress(){
    wp_enqueue_style("style", get_stylesheet_uri())
;}
add_action("wp_enqueue_scripts", "learningWordpress");

//Navigation Menus
register_nav_menus(array(
    "primary" =>__("Primary Menu"),
    "footer" =>__("Footer Menu")
));


//Add featured Image
function addFeaturedImage(){
    add_theme_support( 'post-thumbnails' );
    add_image_size("small-thumbnail", 180,120, true);
    add_image_size("banner-image", 910,210, true);
;}

add_action("after_setup_theme", 'addFeaturedImage');

//Add post format
function addPostFormat(){
    add_theme_support( 'post-formats', array( 'aside', 'gallery' ) )
    ;}

add_action("after_setup_theme", 'addPostFormat');

//Add Widget Locations
function addWidgetLocation(){
    register_sidebar(array(
        "name" => "Sidebar",
        "id" => ""
        ))
    ;}

add_action("widgets_init", 'addWidgetLocation');


?>