
<?php 
/*
Template Name: Special Layout
*/


get_header();
    if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<article class="post page">
    <h2> <a><?php the_title();?></a></h2>
    <div class="info-box">
        <h4>DISCLAIMER</h4>
      <p> FAIR USE NOTICE: This site may contain copyrighted material the use of which has not always been specifically authorized by the copyright owner. Such material is made available to advance understanding of ecological, political, human rights, economic, democracy, scientific, moral, ethical, and social justice issues, etc.</p>
    </div>
    <p><?php the_content();?></p>
</article>

<?php endwhile;

else:
    echo "<p>no content found</p>";
endif;

get_footer();

 ?>