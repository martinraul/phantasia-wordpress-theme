<article class="post <?php if(has_post_thumbnail()){?>has-thumbnail<?php } ?> ">
    <!-- post thumbnail -->
    <div class="post-body">
    <?php if(has_post_thumbnail()){?>
        <div class="post-thumbnail">
            <a href="<?php the_permalink();?>"> <?php the_post_thumbnail("small-thumbnail");?></a>
        </div>
        <?php } ?>
        <div class="post-title">
            <!-- post title -->
            <h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
            <!-- post info -->
            <p class="post-info">
                <?php the_time("m/d/y");?> - by
                <a href="<?php echo get_author_posts_url(get_the_author_meta("ID")); ?>"><?php the_author();?></a>
            </p>
        </div>
        <!-- post -->
        <?php the_content();?>
    </div>
</article>