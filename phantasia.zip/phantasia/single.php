<?php
  get_header(); ?>
  
<div id="primary" class="content-area">
        <?php the_post_thumbnail("banner-image");?>
        <h1><?php the_title(); ?></h1>
        <p><?php the_content();?></p>
     
</div>

<?php
get_footer();
?>