<article class="post post-aside">
<?php the_content(); ?>
</article>